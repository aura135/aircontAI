@echo off
cd /d "%~dp0backend"
if not exist .venv (
  py -3 -m venv .venv
  call .venv\Scripts\activate.bat
  pip install -r requirements.txt
) else (
  call .venv\Scripts\activate.bat
)
if not exist "..\.env" echo WARNING: copy .env.example to .env and fill in Supabase values.
start "" http://localhost:5173/login.html
python -m uvicorn main:app --host 127.0.0.1 --port 5173
pause
