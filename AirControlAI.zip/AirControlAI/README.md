# AirControl AI
Webcam hand tracking -> real Windows mouse/scroll/zoom input. Local agent + web dashboard (Supabase auth). See `desktop-agent/README.md` for gestures, packaging (.exe) and limitations.

## Setup (Windows 10/11, Python 3.10-3.12, webcam)
1. **Supabase**: create a project; SQL Editor -> run `database/schema.sql`. Authentication -> URL config: add `http://localhost:5173` as Site URL / redirect. Project Settings -> API: copy `.env.example` to `.env` (project root) and paste the URL + anon key. Never use the service-role key.
2. **Agent**: double-click `desktop-agent/run-agent.bat` (first run installs dependencies). Allow camera in Windows Settings -> Privacy & security -> Camera.
3. **Dashboard + FastAPI backend**: double-click `run-web.bat` (serves the site and `/api/*` on http://localhost:5173), sign up, sign in.
4. **Pair**: tray icon -> *Show pairing token*, paste it in the dashboard, press START SENSING.

Esc = global emergency stop, F8 = toggle. The agent listens only on 127.0.0.1:8765, only for the dashboard origin, and every command needs the token.

## Test checklist
Move, click, double-click, drag a file, scroll (both axes), zoom in Chrome, right click, Stop (control ends, camera light off), Start (resumes), Esc.

## Backend
`backend/main.py` (FastAPI) serves the dashboard, generates `js/config.js` from `.env`, and exposes `/api/health`, `/api/me`, `/api/settings` (verifies your Supabase session; row-level security still applies). It has no computer-control endpoints.

## Permission errors and Start with Windows
The agent reads the Windows camera privacy setting: **PERMISSION_REQUIRED** means access is denied (follow the on-screen Settings path); **CAMERA_NOT_FOUND** means no camera or it's in use. Start with Windows is a toggle in dashboard Settings or the tray menu, off by default; the agent then launches with sensing OFF.
