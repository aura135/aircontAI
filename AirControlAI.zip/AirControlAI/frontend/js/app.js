const $ = (s) => document.querySelector(s);
const A = window.AIR || {};
const sb = (A.SUPABASE_URL && A.SUPABASE_ANON_KEY) ? supabase.createClient(A.SUPABASE_URL, A.SUPABASE_ANON_KEY) : null;

function banner() {
  if (!sb) document.body.insertAdjacentHTML("afterbegin",
    '<div class="banner">Supabase is not configured. Fill in frontend/js/config.js (see README).</div>');
  return !!sb;
}
async function requireUser() {
  if (!banner()) return null;
  const { data } = await sb.auth.getSession();
  if (!data.session) { location = "login.html"; return null; }
  return data.session.user;
}
async function logout() { await sb.auth.signOut(); location = "login.html"; }

// ---- local agent (WebSocket to 127.0.0.1, token-authenticated) ----
const Agent = {
  ws: null, pend: {}, n: 0, connected: false, on: () => {},
  token: () => localStorage.getItem("air_token") || "",
  connect() {
    if (this.ws && this.ws.readyState < 2) return;
    const w = (this.ws = new WebSocket("ws://127.0.0.1:8765"));
    w.onopen = () => { this.connected = true; this.poll(); };
    w.onclose = () => { this.connected = false; clearInterval(this.t); this.on(null, "DISCONNECTED"); setTimeout(() => this.connect(), 2000); };
    w.onmessage = (e) => {
      const m = JSON.parse(e.data), p = this.pend[m.id];
      if (p) { delete this.pend[m.id]; m.error ? p.rej(new Error(m.error)) : p.res(m); }
      this.on(m.error ? null : m, m.error || null);
    };
  },
  send(cmd, data) {
    return new Promise((res, rej) => {
      if (!this.connected) return rej(new Error("Agent not connected"));
      const id = ++this.n; this.pend[id] = { res, rej };
      this.ws.send(JSON.stringify({ id, token: this.token(), cmd, data }));
      setTimeout(() => { if (this.pend[id]) { delete this.pend[id]; rej(new Error("timeout")); } }, 4000);
    });
  },
  poll() { clearInterval(this.t); const f = () => this.send("STATUS").catch(() => {}); this.t = setInterval(f, 1500); f(); },
};

// ---- settings UI ----
const SLIDERS = [["sensitivity","Cursor sensitivity",.3,3,.1],["smoothing","Cursor smoothing",0,.9,.05],
  ["scroll_speed","Scroll speed",.2,5,.1],["zoom_sensitivity","Zoom sensitivity",.2,5,.1],
  ["pinch_threshold","Gesture threshold",.1,.6,.01],["cooldown_s","Gesture cooldown (s)",0,1,.01]];
const TOGGLES = [["enable_cursor","Cursor movement"],["enable_click","Click"],["enable_drag","Drag"],
  ["enable_scroll","Scroll"],["enable_zoom","Zoom"],["enable_right_click","Right click"],
  ["natural_scroll","Natural scroll direction"],["show_landmarks","Show hand landmarks"]];

function renderControls(el, nSliders, nToggles, s, onChange) {
  el.innerHTML = "";
  SLIDERS.slice(0, nSliders).forEach(([k, label, lo, hi, st]) => {
    const r = document.createElement("div"); r.className = "row";
    r.innerHTML = `<label>${label} <span class="mu" id="v_${k}">${s[k]}</span></label>
      <input type="range" min="${lo}" max="${hi}" step="${st}" value="${s[k]}">`;
    r.querySelector("input").oninput = (e) => { $("#v_" + k).textContent = e.target.value; onChange({ [k]: +e.target.value }); };
    el.append(r);
  });
  TOGGLES.slice(0, nToggles).forEach(([k, label]) => {
    const r = document.createElement("div"); r.className = "row";
    r.innerHTML = `<label>${label}</label><input type="checkbox" ${s[k] ? "checked" : ""}>`;
    r.querySelector("input").onchange = (e) => onChange({ [k]: e.target.checked });
    el.append(r);
  });
}

function makeSaver(user) {
  let timer, acc = {}, full = {};
  return (patch, current) => {
    Object.assign(acc, patch); full = { ...current, ...acc };
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const p = acc; acc = {};
      try { await Agent.send("UPDATE_SETTINGS", p); } catch (e) { console.warn("Agent:", e.message); }
      try {
        const { data } = await sb.auth.getSession();
        const r = await fetch("/api/settings", { method: "PUT", headers: { Authorization: "Bearer " + data.session.access_token, "Content-Type": "application/json" }, body: JSON.stringify({ settings: full }) });
        if (!r.ok) console.warn("Backend:", r.status);
      } catch (e) { console.warn("Backend:", e.message); }
    }, 400);
  };
}

async function loadStored() {
  try {
    const { data } = await sb.auth.getSession();
    const r = await fetch("/api/settings", { headers: { Authorization: "Bearer " + data.session.access_token } });
    return r.ok ? (await r.json()).settings || {} : {};
  } catch (e) { return {}; }
}
