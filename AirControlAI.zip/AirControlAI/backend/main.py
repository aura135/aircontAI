"""AirControl AI web backend (FastAPI).
- serves the dashboard from ../frontend on http://localhost:5173
- /js/config.js is generated from ../.env (public anon key only)
- /api/* verifies the caller's Supabase session, then reads/writes their
  settings with THEIR token, so Postgres row-level security still applies.
It has no computer-control endpoints; those live only in the local agent."""
import json, os, pathlib

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = pathlib.Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")
URL = os.getenv("SUPABASE_URL", "").rstrip("/")
KEY = os.getenv("SUPABASE_ANON_KEY", "")
app = FastAPI(title="AirControl AI")


async def session_user(auth: str | None) -> tuple[str, str]:
    if not URL or not KEY:
        raise HTTPException(503, "Supabase is not configured in .env")
    if not auth or not auth.lower().startswith("bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = auth[7:]
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(f"{URL}/auth/v1/user", headers={"apikey": KEY, "Authorization": f"Bearer {token}"})
    except httpx.HTTPError:
        raise HTTPException(503, "Supabase unreachable")
    if r.status_code != 200:
        raise HTTPException(401, "Invalid or expired session")
    return r.json()["id"], token


def _headers(token: str) -> dict:
    return {"apikey": KEY, "Authorization": f"Bearer {token}", "Content-Type": "application/json"}


class Payload(BaseModel):
    settings: dict


@app.get("/api/health")
async def health():
    return {"ok": True, "supabase_configured": bool(URL and KEY)}


@app.get("/api/me")
async def me(authorization: str | None = Header(None)):
    uid, _ = await session_user(authorization)
    return {"user_id": uid}


@app.get("/api/settings")
async def get_settings(authorization: str | None = Header(None)):
    uid, token = await session_user(authorization)
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(f"{URL}/rest/v1/user_settings", params={"select": "settings", "user_id": f"eq.{uid}"},
                        headers=_headers(token))
    if r.status_code != 200:
        raise HTTPException(502, "Supabase error reading settings")
    rows = r.json()
    return {"settings": rows[0]["settings"] if rows else {}}


@app.put("/api/settings")
async def put_settings(p: Payload, authorization: str | None = Header(None)):
    uid, token = await session_user(authorization)
    if len(json.dumps(p.settings)) > 8000:
        raise HTTPException(413, "Settings too large")
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.post(f"{URL}/rest/v1/user_settings", params={"on_conflict": "user_id"},
                         headers={**_headers(token), "Prefer": "resolution=merge-duplicates,return=minimal"},
                         json={"user_id": uid, "settings": p.settings})
    if r.status_code not in (200, 201, 204):
        raise HTTPException(502, "Supabase error saving settings")
    return {"ok": True}


@app.get("/js/config.js")
async def config_js():
    body = "window.AIR = " + json.dumps({"SUPABASE_URL": URL, "SUPABASE_ANON_KEY": KEY}) + ";"
    return Response(body, media_type="text/javascript", headers={"Cache-Control": "no-store"})


app.mount("/", StaticFiles(directory=ROOT / "frontend", html=True), name="web")
