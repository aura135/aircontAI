"""Gesture state machine. Pure logic: landmarks in, input actions out.

Postures (decided every frame from landmarks):
  ZOOM    middle+ring+pinky extended (open hand): thumb-index spread = zoom
  SCROLL  index+middle extended, ring+pinky folded: vertical/horizontal motion
  RCLICK  thumb touching middle fingertip (held) with index extended
  CURSOR  anything else: index tip moves the cursor; thumb-index pinch =
          click (short) or drag (hold)
Actions: ("move",x,y) ("down",) ("up",) ("click",) ("rclick",)
         ("scroll",dx,dy) ("zoom",steps)
"""
import math
from settings import Settings

ZOOM_STEP = 0.15  # change in pinch ratio per Ctrl+wheel notch


def dist(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


class GestureEngine:
    def __init__(self, s: Settings, sw: int, sh: int) -> None:
        self.s, self.sw, self.sh = s, sw, sh
        self.reset()

    def reset(self) -> None:
        self.state = "IDLE"      # IDLE MOVING PINCH_START DRAGGING
        self.mode = "NONE"
        self.pos = None          # smoothed cursor position
        self.sent = None         # last position sent
        self.pinched = False
        self.pinch_t = 0.0
        self.last_click = 0.0
        self.rc_t = None
        self.rc_done = False
        self.prev_scroll = None
        self.prev_zoom = None
        self.acc = [0.0, 0.0]
        self.zoom_acc = 0.0
        self.ratio = 0.0

    def release(self):
        """Hand lost / sensing stopped: never leave the mouse button held."""
        acts = [("up",)] if self.state == "DRAGGING" else []
        self.reset()
        return acts

    # ---- helpers -------------------------------------------------------
    @staticmethod
    def _ext(lm, tip, pip) -> bool:
        return dist(lm[tip], lm[0]) > dist(lm[pip], lm[0]) * 1.15

    def _cursor_target(self, lm):
        k = self.s.sensitivity / 0.7  # use central ~70% of the frame at 1.0
        nx = min(1.0, max(0.0, 0.5 + (lm[8][0] - 0.5) * k))
        ny = min(1.0, max(0.0, 0.5 + (lm[8][1] - 0.5) * k))
        return nx * (self.sw - 1), ny * (self.sh - 1)

    # ---- main entry ----------------------------------------------------
    def update(self, lm, now: float):
        if lm is None:
            return self.release()
        s, acts = self.s, []
        size = dist(lm[0], lm[9]) or 1e-6
        idx, mid = self._ext(lm, 8, 6), self._ext(lm, 12, 10)
        rng, pnk = self._ext(lm, 16, 14), self._ext(lm, 20, 18)
        self.ratio = dist(lm[4], lm[8]) / size
        thr = s.pinch_threshold

        rc_cond = (s.enable_right_click and idx and dist(lm[4], lm[12]) / size < thr
                   and self.ratio > thr * 1.5)
        if rc_cond:
            mode = "RCLICK"
        elif mid and rng and pnk:
            mode = "ZOOM"
        elif idx and mid and not rng and not pnk:
            mode = "SCROLL"
        else:
            mode = "CURSOR"

        if mode != "CURSOR" and self.state in ("DRAGGING", "PINCH_START"):
            acts += self.release()           # posture changed mid-pinch
        self.mode = mode
        if mode != "RCLICK":
            self.rc_t, self.rc_done = None, False
        if mode != "SCROLL":
            self.prev_scroll = None
        if mode != "ZOOM":
            self.prev_zoom = None

        if mode == "RCLICK":
            if self.rc_t is None:
                self.rc_t = now
            elif not self.rc_done and now - self.rc_t >= s.right_click_hold_s:
                acts.append(("rclick",))
                self.rc_done = True          # once per hold
        elif mode == "ZOOM":
            if s.enable_zoom and self.prev_zoom is not None:
                self.zoom_acc += (self.ratio - self.prev_zoom) * s.zoom_sensitivity
                steps = int(self.zoom_acc / ZOOM_STEP)
                if steps:
                    acts.append(("zoom", steps))
                    self.zoom_acc -= steps * ZOOM_STEP
            self.prev_zoom = self.ratio
        elif mode == "SCROLL":
            mx = (lm[8][0] + lm[12][0]) / 2
            my = (lm[8][1] + lm[12][1]) / 2
            if s.enable_scroll and self.prev_scroll is not None:
                dx, dy = mx - self.prev_scroll[0], my - self.prev_scroll[1]
                gain = 60 * s.scroll_speed
                sign = 1 if s.natural_scroll else -1
                if abs(dy) > 0.002:
                    self.acc[1] += sign * dy * gain
                if abs(dx) > 0.002:
                    self.acc[0] += dx * gain * (-sign)
                sx, sy = int(self.acc[0]), int(self.acc[1])
                if sx or sy:
                    acts.append(("scroll", sx, sy))
                    self.acc[0] -= sx
                    self.acc[1] -= sy
            self.prev_scroll = (mx, my)
        else:
            acts += self._cursor_mode(lm, now)
        return acts

    def _cursor_mode(self, lm, now: float):
        s, acts, thr = self.s, [], self.s.pinch_threshold
        pinching = self.ratio < thr or (self.pinched and self.ratio < thr * 1.5)

        if pinching and not self.pinched:
            self.pinched, self.pinch_t, self.state = True, now, "PINCH_START"
        elif pinching:
            if (self.state == "PINCH_START" and s.enable_drag
                    and now - self.pinch_t >= s.click_max_s):
                acts.append(("down",))
                self.state = "DRAGGING"
        elif self.pinched:                   # released
            self.pinched = False
            held = now - self.pinch_t
            if self.state == "DRAGGING":
                acts.append(("up",))
            elif (s.enable_click and 0.04 <= held < s.click_max_s
                  and now - self.last_click >= s.cooldown_s):
                acts.append(("click",))      # two quick pinches = double click
                self.last_click = now
            self.state = "MOVING"
        elif self.state == "IDLE":
            self.state = "MOVING"

        # Cursor follows the index tip; frozen during a short pinch so the
        # click lands where you aimed (but moves while dragging).
        if s.enable_cursor and self.state != "PINCH_START":
            tx, ty = self._cursor_target(lm)
            if self.pos is None:
                self.pos = (tx, ty)
            else:
                a = max(0.05, 1.0 - s.smoothing)
                self.pos = (self.pos[0] + (tx - self.pos[0]) * a,
                            self.pos[1] + (ty - self.pos[1]) * a)
            if self.sent is None or dist(self.pos, self.sent) > s.deadzone_px:
                self.sent = self.pos
                acts.append(("move", int(self.pos[0]), int(self.pos[1])))
        return acts
