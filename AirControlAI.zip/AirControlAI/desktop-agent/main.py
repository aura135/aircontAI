"""AirControl AI desktop agent.  F8 = start/stop sensing, Esc = emergency stop.
Window keys: S start/stop, L landmarks, Q quit. Sensing starts OFF (camera off)."""
import ctypes, logging, time
import cv2, numpy as np
from pynput import keyboard

import settings as cfg
import communication, tray
from controller import InputController
from gesture_engine import GestureEngine
from hand_tracker import HandTracker
from permissions import PERM_HELP, camera_denied

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(message)s")
log = logging.getLogger("aircontrol")
WIN = "AirControl AI"
CAM_HELP = ("No camera found, or it is in use by another app. Close other apps using the "
            "camera, or pick another camera index in Settings.")


def screen_size():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # real pixels, not scaled
    except Exception:
        pass
    u = ctypes.windll.user32
    return u.GetSystemMetrics(0), u.GetSystemMetrics(1)


class App:
    def __init__(self) -> None:
        self.s = cfg.load()
        self.sensing, self.quit, self.cap, self.msg = False, False, None, ""
        self.hand, self.token, self.err_code = False, "", ""
        self.sw, self.sh = screen_size()
        self.tracker = HandTracker()
        self.engine = GestureEngine(self.s, self.sw, self.sh)
        self.io = InputController()

    # global hotkeys (work in any app)
    def on_key(self, key) -> None:
        if key == keyboard.Key.esc:
            self.sensing = False            # immediate: main loop gates input
            self.io.release_all()
        elif key == keyboard.Key.f8:
            self.sensing = not self.sensing
            self.clear_error()

    def clear_error(self) -> None:
        self.msg, self.err_code = "", ""

    def fail(self) -> None:
        self.sensing = False
        if camera_denied():
            self.err_code, self.msg = "PERMISSION_REQUIRED", PERM_HELP
        else:
            self.err_code, self.msg = "CAMERA_NOT_FOUND", CAM_HELP
        log.error(self.msg)

    def sync_camera(self) -> None:
        if self.sensing and self.cap is None:
            cap = cv2.VideoCapture(self.s.camera_index, cv2.CAP_DSHOW)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.s.width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.s.height)
            if not cap.isOpened():
                cap.release(); self.fail()
            else:
                self.cap = cap; self.engine.reset()
        elif not self.sensing and self.cap is not None:
            self.io.release_all(); self.engine.reset()
            self.cap.release(); self.cap = None   # camera light off

    def overlay(self, frame, lm, info) -> None:
        if info and self.s.show_landmarks:
            self.tracker.draw(frame, info[0])
        h, w = frame.shape[:2]
        e = self.engine
        lines = ["Camera: ACTIVE", f"Sensing: {'ACTIVE' if self.sensing else 'STOPPED'}",
                 f"Hand: {'YES' if lm else 'NO'}  Confidence: {int(info[1]*100) if info else 0}%"]
        if lm:
            lines += [f"Index: {int(lm[8][0]*w)},{int(lm[8][1]*h)}  Thumb: {int(lm[4][0]*w)},{int(lm[4][1]*h)}",
                      f"Pinch ratio: {e.ratio:.2f} (click < {self.s.pinch_threshold})",
                      f"Mode: {e.mode}  State: {e.state}"]
        for i, t in enumerate(lines):
            cv2.putText(frame, t, (8, 20 + 20 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        cv2.putText(frame, "Esc = EMERGENCY STOP | F8 start/stop", (8, h - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

    def idle_frame(self):
        img = np.zeros((300, 640, 3), np.uint8)
        lines = ["Camera: OFF   Sensing: STOPPED", "Press F8 (or S in this window) to start",
                 "Esc = emergency stop, Q = quit"] + ([self.msg[:70], self.msg[70:140]] if self.msg else [])
        for i, t in enumerate(lines):
            cv2.putText(img, t, (10, 40 + 30 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)
        return img

    def run(self) -> None:
        keyboard.Listener(on_press=self.on_key).start()
        communication.start_server(self)
        tray.start_tray(self)
        log.info('Dashboard pairing token is in agent-token.txt (tray menu > Show pairing token)')
        while not self.quit:
            self.sync_camera()
            if self.cap is None:
                self.hand = False
                frame = self.idle_frame()
            else:
                ok, frame = self.cap.read()
                if not ok:
                    self.fail()
                    continue
                frame = cv2.flip(frame, 1)            # mirror: right = right
                lm, info = self.tracker.process(frame)
                self.hand = lm is not None
                acts = self.engine.update(lm, time.time())
                if self.sensing:                      # re-checked right before input
                    self.io.apply(acts)
                self.overlay(frame, lm, info)
            cv2.imshow(WIN, frame)
            k = cv2.waitKey(1) & 0xFF
            if k == ord("q"):
                self.quit = True
            elif k == ord("s"):
                self.sensing = not self.sensing; self.clear_error()
            elif k == ord("l"):
                self.s.show_landmarks = not self.s.show_landmarks
        self.sensing = False
        self.sync_camera()
        self.tracker.close()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    App().run()
