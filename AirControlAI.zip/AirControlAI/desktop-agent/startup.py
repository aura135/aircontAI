"""Opt-in 'Start with Windows' via the per-user Run key (no admin needed).
The agent still starts with sensing OFF; the camera never turns on by itself."""
import pathlib, sys, winreg

KEY, NAME = r"Software\Microsoft\Windows\CurrentVersion\Run", "AirControlAI"


def _command() -> str:
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}"'
    py = pathlib.Path(sys.executable)
    pyw = py.with_name("pythonw.exe")
    return f'"{pyw if pyw.exists() else py}" "{pathlib.Path(__file__).with_name("main.py")}"'


def is_enabled() -> bool:
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY) as k:
            winreg.QueryValueEx(k, NAME)
            return True
    except OSError:
        return False


def set_enabled(on: bool) -> None:
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_SET_VALUE) as k:
        if on:
            winreg.SetValueEx(k, NAME, 0, winreg.REG_SZ, _command())
        else:
            try:
                winreg.DeleteValue(k, NAME)
            except FileNotFoundError:
                pass
