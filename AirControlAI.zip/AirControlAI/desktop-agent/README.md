# AirControl AI - desktop agent (milestone 1)

Real webcam hand tracking (MediaPipe) -> real Windows mouse/scroll/zoom input (pynput). Works across all apps. All processing is local; no frames are saved or uploaded. Sensing starts OFF and the camera is released when stopped.

## Run (Windows 10/11, Python 3.10-3.12, webcam)
Double-click `run-agent.bat`, or:
```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```
Camera: Windows Settings > Privacy & security > Camera -> allow camera + desktop apps. No admin rights needed (admin only if you control an app that itself runs as admin).

## Controls
F8 start/stop (global) | **Esc = emergency stop** (global) | window: S, L (landmarks), Q.

## Gestures (right hand facing the camera, palm toward it)
| Action | Gesture |
|---|---|
| Move cursor | Index finger up, other fingers curled; move hand |
| Click | Quick thumb+index pinch (two quick pinches = double click) |
| Drag | Pinch and hold ~0.3 s, move, open fingers to drop |
| Scroll | Index+middle up together, ring/pinky curled; move up/down/left/right |
| Zoom | Open hand (middle, ring, pinky up); spread/close thumb+index = Ctrl+wheel |
| Right click | Touch thumb to middle fingertip, hold ~0.35 s, index up |

Tune everything in `settings.json` (sensitivity, smoothing, thresholds, per-gesture enable, scroll direction).

## Limitations
Accuracy depends on lighting, camera angle, hand distance, occlusion and webcam resolution; there is some latency. Zoom only works in apps that honor Ctrl+wheel. Windows blocks input into elevated windows unless the agent is also elevated.

## Package (.exe)
```
pip install pyinstaller
pyinstaller --onefile --name AirControlAI --collect-data mediapipe --collect-binaries mediapipe main.py
```
