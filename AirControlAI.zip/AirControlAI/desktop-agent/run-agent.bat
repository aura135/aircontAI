@echo off
cd /d "%~dp0"
if not exist .venv (
  py -3.11 -m venv .venv || py -3.10 -m venv .venv || py -3.12 -m venv .venv || (echo Install Python 3.10-3.12 & pause & exit /b 1)
  call .venv\Scripts\activate.bat
  pip install -r requirements.txt
) else (
  call .venv\Scripts\activate.bat
)
python main.py
pause
