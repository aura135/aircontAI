"""Persistent settings (settings.json next to this file)."""
import json, logging, pathlib
from dataclasses import dataclass, asdict, fields

PATH = pathlib.Path(__file__).with_name("settings.json")
log = logging.getLogger("aircontrol.settings")


@dataclass
class Settings:
    camera_index: int = 0
    width: int = 640
    height: int = 480
    sensitivity: float = 1.0        # 0.5 (slow) .. 2.0 (fast)
    smoothing: float = 0.6          # 0 (raw) .. 0.9 (very smooth)
    deadzone_px: int = 4
    scroll_speed: float = 1.0
    natural_scroll: bool = False    # False: fingers up = scroll up
    zoom_sensitivity: float = 1.0
    pinch_threshold: float = 0.30   # thumb-index distance / palm size
    click_max_s: float = 0.30       # shorter pinch = click, longer = drag
    cooldown_s: float = 0.12
    right_click_hold_s: float = 0.35
    enable_cursor: bool = True
    enable_click: bool = True
    enable_drag: bool = True
    enable_scroll: bool = True
    enable_zoom: bool = True
    enable_right_click: bool = True
    show_landmarks: bool = True


def load() -> Settings:
    s = Settings()
    try:
        data = json.loads(PATH.read_text())
        names = {f.name for f in fields(Settings)}
        for k, v in data.items():
            if k in names:
                setattr(s, k, v)
    except FileNotFoundError:
        save(s)
    except Exception as e:  # corrupt file: keep defaults, say so
        log.error("Invalid settings.json (%s); using defaults", e)
    return s


def save(s: Settings) -> None:
    PATH.write_text(json.dumps(asdict(s), indent=2))
