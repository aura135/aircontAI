"""Applies engine actions as real Windows input (pynput -> SendInput)."""
import logging
from pynput.keyboard import Controller as Keys, Key
from pynput.mouse import Button, Controller as Mouse

log = logging.getLogger("aircontrol.input")


class InputController:
    def __init__(self) -> None:
        self.mouse, self.keys, self.down = Mouse(), Keys(), False

    def apply(self, acts) -> None:
        for a in acts:
            try:
                k = a[0]
                if k == "move":
                    self.mouse.position = (a[1], a[2])
                elif k == "down":
                    self.mouse.press(Button.left); self.down = True
                elif k == "up":
                    self.mouse.release(Button.left); self.down = False
                elif k == "click":
                    self.mouse.click(Button.left)
                elif k == "rclick":
                    self.mouse.click(Button.right)
                elif k == "scroll":
                    self.mouse.scroll(a[1], a[2])
                elif k == "zoom":   # Ctrl + wheel; apps that ignore it won't zoom
                    with self.keys.pressed(Key.ctrl):
                        self.mouse.scroll(0, a[1])
            except Exception:
                log.exception("Input action failed: %s", a)

    def release_all(self) -> None:
        if self.down:
            try:
                self.mouse.release(Button.left)
            except Exception:
                log.exception("Could not release mouse button")
            self.down = False
