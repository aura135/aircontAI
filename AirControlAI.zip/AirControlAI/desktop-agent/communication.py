"""Local WebSocket control channel for the dashboard.
Security: binds to 127.0.0.1 only, accepts only the dashboard's origin, and
every command needs the pairing token from agent-token.txt. Commands:
START STOP STATUS GET_SETTINGS UPDATE_SETTINGS (validated + range-clamped)."""
import asyncio, json, logging, pathlib, secrets, threading
from dataclasses import asdict, fields

import websockets
import settings as cfg
import startup

log = logging.getLogger("aircontrol.comm")
PORT = 8765
ORIGINS = [f"http://{h}:5173" for h in ("localhost", "127.0.0.1")]
TOKEN_PATH = pathlib.Path(__file__).with_name("agent-token.txt")
RANGES = {"sensitivity": (0.3, 3), "smoothing": (0, 0.95), "deadzone_px": (0, 30),
          "scroll_speed": (0.2, 5), "zoom_sensitivity": (0.2, 5),
          "pinch_threshold": (0.1, 0.6), "click_max_s": (0.1, 1), "cooldown_s": (0, 1),
          "right_click_hold_s": (0.1, 2), "camera_index": (0, 10),
          "width": (320, 1920), "height": (240, 1080)}


def get_token() -> str:
    if TOKEN_PATH.exists():
        return TOKEN_PATH.read_text().strip()
    t = secrets.token_urlsafe(24)
    TOKEN_PATH.write_text(t)
    return t


def status(app) -> dict:
    st = (app.err_code or "CAMERA_ERROR") if app.msg else ("SENSING" if app.sensing else "STOPPED")
    cam = "ACTIVE" if app.cap is not None else ("ERROR" if app.msg else "OFF")
    return {"status": st, "camera": cam, "hand": app.hand, "message": app.msg,
            "settings": asdict(app.s), "autostart": startup.is_enabled()}


def apply_settings(app, data: dict) -> None:
    types = {f.name: f.type for f in fields(cfg.Settings)}
    for k, v in data.items():
        t = types.get(k)
        if t is None:
            raise ValueError(f"unknown setting: {k}")
        if t is bool:
            ok = isinstance(v, bool)
        else:
            ok = isinstance(v, (int, float)) and not isinstance(v, bool)
        if not ok:
            raise ValueError(f"invalid value for {k}")
        if k in RANGES:
            lo, hi = RANGES[k]
            v = min(hi, max(lo, v))
            v = int(v) if t is int else float(v)
        setattr(app.s, k, v)


async def handler(ws, app) -> None:
    async for raw in ws:
        mid = None
        try:
            m = json.loads(raw)
            mid = m.get("id")
            if not secrets.compare_digest(str(m.get("token", "")), app.token):
                await ws.send(json.dumps({"id": mid, "error": "UNAUTHORIZED"}))
                continue
            cmd = m.get("cmd")
            if cmd == "START":
                app.clear_error(); app.sensing = True
            elif cmd == "STOP":
                app.sensing = False
                app.io.release_all()
            elif cmd == "SET_AUTOSTART":
                startup.set_enabled(bool((m.get("data") or {}).get("enabled")))
            elif cmd == "UPDATE_SETTINGS":
                apply_settings(app, m.get("data") or {})
                cfg.save(app.s)
            elif cmd not in ("STATUS", "GET_SETTINGS"):
                raise ValueError("unknown command")
            reply = {"id": mid, **status(app)}
        except Exception as e:
            reply = {"id": mid, "error": str(e)}
        await ws.send(json.dumps(reply))


def start_server(app) -> None:
    app.token = get_token()

    def run() -> None:
        async def main():
            async with websockets.serve(lambda ws: handler(ws, app), "127.0.0.1", PORT, origins=ORIGINS):
                await asyncio.Future()
        try:
            asyncio.run(main())
        except Exception:
            log.exception("Control channel failed (is port %s in use?)", PORT)
    threading.Thread(target=run, daemon=True).start()
