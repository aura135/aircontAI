"""Detect Windows camera privacy denial (registry ConsentStore)."""
import winreg

BASE = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam"
PERM_HELP = ("Camera permission is not available. Open Windows Settings > Privacy & security > "
             "Camera, turn on camera access and 'Let desktop apps access your camera'.")


def _value(root, sub):
    try:
        with winreg.OpenKey(root, BASE + sub) as k:
            return winreg.QueryValueEx(k, "Value")[0]
    except OSError:
        return None


def camera_denied() -> bool:
    return any(_value(r, s) == "Deny"
               for r in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE)
               for s in ("", r"\NonPackaged"))
