"""MediaPipe Hands wrapper: returns 21 normalized landmarks of one hand."""
import cv2
import mediapipe as mp


class HandTracker:
    def __init__(self) -> None:
        self._hands = mp.solutions.hands.Hands(
            max_num_hands=1, model_complexity=0,
            min_detection_confidence=0.7, min_tracking_confidence=0.6)
        self._draw = mp.solutions.drawing_utils

    def process(self, frame_bgr):
        res = self._hands.process(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB))
        if not res.multi_hand_landmarks:
            return None, None
        hand = res.multi_hand_landmarks[0]
        conf = res.multi_handedness[0].classification[0].score
        return [(p.x, p.y) for p in hand.landmark], (hand, conf)

    def draw(self, frame, hand) -> None:
        self._draw.draw_landmarks(frame, hand, mp.solutions.hands.HAND_CONNECTIONS)

    def close(self) -> None:
        self._hands.close()
