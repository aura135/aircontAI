"""System-tray icon: status, start/stop, settings, dashboard, exit."""
import os, threading, time, webbrowser
import pystray
from PIL import Image, ImageDraw
import startup
from communication import TOKEN_PATH

DASH = "http://localhost:5173/"


def _img(color: str) -> Image.Image:
    img = Image.new("RGB", (64, 64), "#111111")
    ImageDraw.Draw(img).ellipse((12, 12, 52, 52), fill=color)
    return img


def start_tray(app) -> None:
    def start(i, it): app.clear_error(); app.sensing = True
    def stop(i, it): app.sensing = False; app.io.release_all()
    def quit_(i, it): app.quit = True; i.stop()
    menu = pystray.Menu(
        pystray.MenuItem(lambda i: "Status: ● " + ("SENSING ACTIVE" if app.sensing else "STOPPED"), None, enabled=False),
        pystray.MenuItem("Start Sensing", start),
        pystray.MenuItem("Stop Sensing", stop),
        pystray.MenuItem("Settings", lambda i, it: webbrowser.open(DASH + "settings.html")),
        pystray.MenuItem("Open Dashboard", lambda i, it: webbrowser.open(DASH + "dashboard.html")),
        pystray.MenuItem("Start with Windows", lambda i, it: startup.set_enabled(not startup.is_enabled()),
                         checked=lambda it: startup.is_enabled()),
        pystray.MenuItem("Show pairing token", lambda i, it: os.startfile(TOKEN_PATH)),
        pystray.MenuItem("Exit", quit_))
    icon = pystray.Icon("AirControl AI", _img("gray"), "AirControl AI", menu)
    icon.run_detached()

    def refresh() -> None:
        while not app.quit:
            icon.icon = _img("#22c55e" if app.sensing else "gray")
            icon.title = "AirControl AI - " + ("SENSING ACTIVE" if app.sensing else "STOPPED")
            time.sleep(1)
    threading.Thread(target=refresh, daemon=True).start()
